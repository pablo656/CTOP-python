nombre = input("escribe tu nombre:");
print("hola,",nombre)
print("Cantidad de caracteres: ", len(nombre))